<script>
  import { schedule } from "$lib/data/schedule.js";
   console.log("Schedule Page Loaded");
   console.log("Schedule Data:",schedule);
</script>

<h1>Conference Schedule</h1>
<ul>
  {#each schedule as item}
    <li><strong>{item.time}</strong> - {item.event}</li>
  {/each}
</ul>

<style>


  h1 {
    text-align: center;
    margin-bottom: 20px;
  }
  ul {
    list-style: none;
    padding: 0;
  }
  li {
    background: #f4f4f4;
    padding: 10px;
    margin: 5px 0;
    border-radius: 5px;
  }
</style>

<script>
  let schedule = [
    {
      date: "2025-06-15",
      sessions: [
        { time: "09:00 AM", topic: "Opening Keynote", speaker: "Dr. Jane Smith" },
        { time: "10:30 AM", topic: "AI in 2025", speaker: "John Doe" },
        { time: "01:00 PM", topic: "Future of Web Development", speaker: "Alice Johnson" }
      ]
    },
    {
      date: "2025-06-16",
      sessions: [
        { time: "09:00 AM", topic: "Cybersecurity Trends", speaker: "Robert Brown" },
        { time: "11:00 AM", topic: "Blockchain for Developers", speaker: "Sophia Wilson" },
        { time: "02:00 PM", topic: "Closing Panel", speaker: "Multiple Speakers" }
      ]
    }
  ];
</script>

<style>
  .schedule-container {
    max-width: 800px;
    margin: auto;
    padding: 20px;
  }
  .date-header {
    font-size: 1.5em;
    font-weight: bold;
    margin-top: 20px;
    border-bottom: 2px solid #333;
    padding-bottom: 5px;
  }
  .session {
    padding: 10px;
    border-bottom: 1px solid #ddd;
  }
  .session-time {
    font-weight: bold;
  }
</style>

<main class="schedule-container">
  <h1>Conference Schedule</h1>
  {#each schedule as day}
    <div class="date-header">{day.date}</div>
    {#each day.sessions as session}
      <div class="session">
        <span class="session-time">{session.time}</span> -
        <span class="session-topic">{session.topic}</span>
        <br />
        <small>Speaker: {session.speaker}</small>
      </div>
    {/each}
  {/each}
</main>
